<?php
session_start();
require_once 'config/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];
    $role = 'user';

    if (!$email || $password !== $confirm || strlen($password) < 6) {
        $_SESSION['error'] = "Erreur de validation.";
        header('Location: Inscription.php');
        exit;
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$username, $email, $hashed, $role]);

    $_SESSION['success'] = "Compte créé. Connectez-vous.";
    header('Location: Login.php');
    exit;
}
?>

<!-- HTML formulaire -->

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <header>
        <h1>Inscription</h1>
    </header>
    <nav>
        <a href="Accueil2.php">Accueil</a>
        <a href="A propos de moi.php">À propos de moi</a>
    </nav>
    <link
        rel="stylesheet"
        href="Style2.css">
</head>
<body>
    <form method="POST">
        <input name="username" placeholder="Nom d'utilisateur" required />
        <input name="email" type="email" placeholder="Email" required />
        <input name="password" type="password" placeholder="Mot de passe" required />
        <input name="confirm" type="password" placeholder="Confirmer" required />
        <button type="submit">S'inscrire</button>
    </form>
</body>
</html>