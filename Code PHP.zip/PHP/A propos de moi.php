<?php
session_start();
if (!isset($_SESSION['competences'])) {
    $_SESSION['competences'] = [
        ["nom" => "PHP", 'niveau' => 4],
        ["nom" => "HTML/CSS", 'niveau' => 3],
        ["nom" => "JavaScript", 'niveau' => 1]
    ];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compétences</title>
    <link
        rel="stylesheet"
        href="Style2.css">
</head>
<body>
    <header>
        <h1>Mes Compétences</h1>
    </header>
    <nav>
        <a href="Accueil2.php">Accueil</a>
        <a href="Login.php">Connexion</a>
        <a href="Inscription.php">Inscription</a>
    </nav>
    <main>
        <ul>
            <?php foreach ($_SESSION['competences'] as $competence) : ?>
                <li>
                    <strong><?php echo htmlspecialchars($competence['nom']); ?></strong>
                    : Niveau <?php echo htmlspecialchars($competence["niveau"]); ?>/5
                </li>
            <?php endforeach; ?>
        </ul>
    </main>
</body>
</html>
