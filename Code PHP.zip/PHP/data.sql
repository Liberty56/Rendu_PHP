-- Création de la base
CREATE DATABASE IF NOT EXISTS projetb2;
USE projetb2;

-- Utilisateur BDD
CREATE USER IF NOT EXISTS 'projetb2'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON projetb2.* TO 'projetb2'@'localhost';

-- Tables
DROP TABLE IF EXISTS users, skills, user_skills, projects;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  email VARCHAR(100),
  password VARCHAR(255),
  role ENUM('user', 'admin') DEFAULT 'user'
);

CREATE TABLE skills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100)
);

CREATE TABLE user_skills (
  user_id INT,
  skill_id INT,
  level ENUM('débutant', 'intermédiaire', 'avancé', 'expert'),
  PRIMARY KEY (user_id, skill_id)
);

CREATE TABLE projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  title VARCHAR(100),
  description TEXT,
  image VARCHAR(255),
  link VARCHAR(255)
);

-- Données test
INSERT INTO users (username, email, password, role) VALUES
('admin', 'admin@mail.com',  'password', 'admin'), -- password
('alice', 'alice@mail.com', 'password', 'user'),
('bob',   'bob@mail.com',   'password', 'user');

INSERT INTO skills (name) VALUES ('HTML'), ('CSS'), ('PHP'), ('JavaScript');

INSERT INTO user_skills (user_id, skill_id, level) VALUES
(2, 1, 'intermédiaire'),
(2, 3, 'débutant'),
(3, 2, 'avancé'),
(3, 4, 'expert');

INSERT INTO projects (user_id, title, description, image, link) VALUES
(2, 'Site CV', 'Portfolio personnel', NULL, 'https://example.com'),
(2, 'Blog PHP', 'Blog dynamique', NULL, 'https://example.com'),
(2, 'API REST', 'Backend simple', NULL, 'https://example.com'),
(3, 'Site photo', 'Galerie', NULL, 'https://example.com'),
(3, 'Jeu JS', 'Jeu interactif', NULL, 'https://example.com'),
(3, 'App météo', 'App météo API', NULL, 'https://example.com');
