<?php
session_start();

// Initialisez le tableau de compétences dans la session s'il n'est pas déjà défini
if (!isset($_SESSION['competences2'])) {
    $_SESSION['competences2'] = [];
}

// Vérifiez si le formulaire a été soumis pour ajouter une compétence
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['competence']) && isset($_POST['niveau'])) {
        $nom = htmlspecialchars($_POST['competence']);
        $niveau = (int)$_POST['niveau'];

        // Ajoutez les valeurs à la session
        $_SESSION['competences2'][] = [
            "nom" => $nom,
            "niveau" => $niveau
        ];

        // Redirigez pour éviter la resoumission du formulaire
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Vérifiez si le formulaire a été soumis pour supprimer une compétence
    if (isset($_POST['delete_index'])) {
        $deleteIndex = (int)$_POST['delete_index'];

        // Supprimez la compétence de la session
        if (isset($_SESSION['competences2'][$deleteIndex])) {
            unset($_SESSION['competences2'][$deleteIndex]);
            // Réorganisez les indices du tableau
            $_SESSION['competences2'] = array_values($_SESSION['competences2']);
        }

        // Redirigez pour éviter la resoumission du formulaire
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Compétence</title>
    <link rel="stylesheet" href="Style2.css">
</head>
<body>
    <header>
        <h1>Vos compétences</h1>
    </header>
    <nav>
        <a href="Accueil2.php">Accueil</a>
        <a href="Projet.php">Vos Projets</a>
        <a href="Logout.php">Se déconnecter</a>
    </nav>
    <form method="post">
        <label for="competence">Nom de la Compétence :</label>
        <input type="text" id="competence" name="competence" required>

        <label for="niveau">Niveau :</label>
        <select id="niveau" name="niveau" required>
            <?php for ($i = 1; $i <= 5; $i++) : ?>
                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
            <?php endfor; ?>
        </select>

        <button type="submit">Ajouter</button>
    </form>

    <h2>Liste</h2>
    <ul>
        <?php foreach ($_SESSION['competences2'] as $index => $competence): ?>
            <li>
                <strong><?php echo $competence['nom']; ?></strong>
                : Niveau <?php echo $competence['niveau']; ?>/5
                <form method="post" style="display: inline;">
                    <input type="hidden" name="delete_index" value="<?php echo $index; ?>">
                    <button type="submit">Supprimer</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
