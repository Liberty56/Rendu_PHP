<?php
session_start();

// Vérifiez si le fichier de configuration existe
$configFile = __DIR__ . '/config/connexion.php';
if (!file_exists($configFile)) {
    die("Le fichier de configuration de la base de données est introuvable.");
}

require_once $configFile;

// Activez l'affichage des erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;

            if ($remember) {
                setcookie('remember_me', $user['id'], time() + (86400 * 30), "/", "", false, true);
            }


            // Vérifiez que le chemin est correct
            header('Location: Vos compétences.php');
            exit;
        } else {
            $_SESSION['error'] = "Identifiants invalides.";
            header('Location: Login.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur de base de données : " . $e->getMessage();
        header('Location: Login.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <header>
        <h1>Connexion</h1>
    </header>
    <nav>
        <a href="Accueil2.php">Accueil</a>
        <a href="A propos de moi.php">À propos de moi</a>
        <a href="Inscription.php">Inscription</a>
    </nav>
    <link rel="stylesheet" href="Style2.css">
</head>
<body>
    <h1>Connexion</h1>
    <?php if (isset($_SESSION['error'])): ?>
        <p style="color:red"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>
    <form method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <br>
        <label for="password">Mot de passe:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <label>
            <input type="checkbox" name="remember" <?php if (isset($_POST['remember'])) echo 'checked'; ?>>
            Se souvenir de moi
        </label>
        <br>
        <button type="submit">Se connecter</button>
    </form>
</body>
</html>
