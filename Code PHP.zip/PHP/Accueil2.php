<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 0; padding: 0; }
        header, nav { background-color: #333; color: white; padding: 10px; }
        nav a { color: white; margin: 0 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
    </style>
    <link
        rel="stylesheet"
        href="Style2.css">
</head>
<body>
    <header>
        <h1>Bienvenue sur mon site </h1>
    </header>
    <nav>
        <a href="A propos de moi.php">À propos de moi</a>
        <a href="Login.php">Connexion</a>
        <a href="Inscription.php">Inscription</a>
    </nav>
    <main>
        <section>
            <img src="profil.png" alt="Photo de profil" style="width:200px; border-radius:50%;">
            <h2>Introduction</h2>
            <p>Bonjour, je suis un étudiant passioné par le domaine de l'informatique. Sur ce site vous trouverez mes compétences personnelles, avec possibilité pour vous de rajouter des compétences avec le niveau de votre choix /5.</p>
        </section>
    </main>
</body>
</html>
