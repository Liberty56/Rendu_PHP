<?php
session_start();
// Crée le dossier uploads s'il n'existe pas
if (!is_dir('uploads')) {
    mkdir('uploads', 0755, true);
}

$message = '';
$data = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données
    $titre = trim($_POST['titre'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $lien = trim($_POST['lien'] ?? '');

    // Validation basique
    if (!$titre || !$description || !$lien) {
        $message = 'Veuillez remplir tous les champs.';
    } elseif (!filter_var($lien, FILTER_VALIDATE_URL)) {
        $message = 'Lien invalide.';
    } elseif (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $message = 'Erreur lors de l\'upload de l\'image.';
    } else {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = basename($_FILES['image']['name']);
        $fileSize = $_FILES['image']['size'];
        $fileType = mime_content_type($fileTmpPath);

        // Vérification type MIME basique (jpg, png, gif)
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($fileType, $allowedTypes)) {
            $message = 'Format d\'image non supporté. Seuls JPG, PNG, GIF sont autorisés.';
        } else {
            // Génération d'un nom unique pour éviter les conflits
            $ext = pathinfo($fileName, PATHINFO_EXTENSION);
            $newFileName = uniqid('img_', true) . '.' . $ext;
            $destPath = 'uploads/' . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $message = 'Fichier envoyé avec succès !';

                // Préparer les données à afficher
                $data = [
                    'titre' => htmlspecialchars($titre),
                    'description' => htmlspecialchars($description),
                    'lien' => htmlspecialchars($lien),
                    'image' => $destPath,
                ];
            } else {
                $message = 'Erreur lors de la sauvegarde de l\'image.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Vos Projets</title>
    <link rel="stylesheet" href="Style2.css">
</head>
<body>
    <header>
        <h1>Projets</h1>
    </header>
    <nav>
        <a href="Accueil2.php">Accueil</a>
        <a href="Vos compétences.php">Vos compétences</a>
        <a href="Logout.php">Se déconnecter</a>
    </nav>
    <div class="form-container">

        <?php if ($message): ?>
            <div class="message <?php echo $data ? 'success' : ''; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <form action="" method="post" enctype="multipart/form-data">
            <label for="titre">Titre</label>
            <input type="text" id="titre" name="titre" placeholder="Entrez le titre" value="<?php echo htmlspecialchars($_POST['titre'] ?? ''); ?>" required />

            <label for="description">Description</label>
            <textarea id="description" name="description" placeholder="Entrez la description" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>

            <label for="image">Image</label>
            <input type="file" id="image" name="image" accept="image/*" required />

            <label for="lien">Lien</label>
            <input type="url" id="lien" name="lien" placeholder="https://example.com" value="<?php echo htmlspecialchars($_POST['lien'] ?? ''); ?>" required />

            <button type="submit">Envoyer</button>
        </form>

        <?php if ($data): ?>
            <div class="result">
                <h3><?php echo $data['titre']; ?></h3>
                <p><?php echo nl2br($data['description']); ?></p>
                <p><strong>Lien :</strong> <a href="<?php echo $data['lien']; ?>" target="_blank" rel="noopener"><?php echo $data['lien']; ?></a></p>
                <img src="<?php echo $data['image']; ?>" alt="Image uploadée" />
                <form method="post" style="display: inline;">
                    <input type="hidden" name="delete_index" value="<?php echo $index; ?>">
                    <button type="submit">Supprimer</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
